package com.dao;
import java.sql.*;
public class DB {
public static Connection getCon() throws ClassNotFoundException, SQLException{
	Class.forName("com.mysql.jdbc.Driver");
	String url = "jdbc:mysql://localhost:3306/db";
	String user = "root";
	String password = "";

	Connection con = DriverManager.getConnection(url, user, password);
	if (con != null) {
		System.out.println("Database Connected successfully");
	} else {
		System.out.println("Database Connection failed");
	}
	return con;

}
}
