package com.servlets;  

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.StudentBean;
import com.dao.StudentDao;
@WebServlet("/ViewStudent")
public class ViewStudent extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8915010061043517851L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>View Student</title>");
		out.println("<link rel='stylesheet' href='resources/bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("navStudent.html").include(request, response);
		out.println("<div class='container'>");
		
		out.println("<div align='center'>"); 
		
		out.println("<h2>View Student</h2>");
		out.println(" <div class='panel panel-default'>");
		out.println("  <div class='panel-body'>");
		
	//	out.print("<h2>View Students</h2>");
	
		List<StudentBean> list=StudentDao.getAllRecords();
		out.println("<table class='table table-bordered table-striped'>");
		out.print("<tr><th>Rollno</th><th>S_Name</th><th>Email</th><th>Gender</th><th>Course</th><th>Fee</th><th>paid</th><th>due</th><th>address</th><th>contact</th><th>Edit</th><th>Delete</th>");
		for(StudentBean bean:list){
			out.print("<tr><td>"+bean.getRollno()+"</td><td>"+bean.getS_Name()+"</td><td>"+bean.getEmail()+"</td><td>"+bean.getGender()+"</td><td>"+bean.getCourse()+"</td><td>"+bean.getFee()+"</td><td>"+bean.getPaid()+"</td><td>"+bean.getDue()+"</td><td>"+bean.getAddress()+"</td><td>"+bean.getContact()+"</td><td><a href='EditStudentForm?rollno="+bean.getRollno()+"'>Edit</a></td><td><a href='DeleteStudent?rollno="+bean.getRollno()+"'>Delete</a></td></tr>");
		}
		out.println("</table>");
		
		out.println("<tr><td colspan='2' align='center'> <input type=button class='btn btn-info' onClick=\"history.back()\"value='Back'></td></tr>");

		out.println("</div>");
		out.println("</div>");
		out.println("</div>");
		
		
		
		out.println("</div>");
		request.getRequestDispatcher("footer.html").include(request, response);
		out.println("</body>");
		out.println("</html>");
		
		out.close();
	}

}
